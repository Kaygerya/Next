﻿using MyNextMatch.Core.Entities;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace MyNextMatch.Service.Base
{
    public class ApiServiceBase
    {

    }
}
