﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyNextMatch.Core.Entities
{
    public interface IEntity
    {
        IEntity GetObject();
    }
}
