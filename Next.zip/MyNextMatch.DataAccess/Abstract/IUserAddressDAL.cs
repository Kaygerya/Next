﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyNextMatch.DataAccess.Abstract
{
    public interface IUserAddressDAL
    {
    }
}
