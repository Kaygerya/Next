﻿using MyNextMatch.DataAccess.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyNextMatch.DataAccess.Services
{
    public class APIUserAddressDAL : IUserAddressDAL
    {
    }
}
